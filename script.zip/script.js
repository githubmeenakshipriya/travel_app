// Function to validate booking form
function validateBooking() {
  var whereTo = document.getElementById('whereTo').value;
  var howMany = document.getElementById('howMany').value;
  var startDate = document.getElementById('startDate').value;
  var endDate = document.getElementById('endDate').value;
  var description = document.getElementById('description').value;

  if (whereTo && howMany && startDate && endDate && description) {
    alert('Booking successful!');
  } else {
    alert('Please fill in all fields.');
  }
}

